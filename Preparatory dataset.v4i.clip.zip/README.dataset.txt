# Preparatory dataset > 2025-09-08 11:27pm
https://universe.roboflow.com/project1-ztzut/preparatory-dataset-nxcck

Provided by a Roboflow user
License: CC BY 4.0

